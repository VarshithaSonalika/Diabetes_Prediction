import numpy as np
from flask import Flask, request, render_template
import pickle

pickle_in = open('Classifier.pkl', "rb")
LR = pickle.load(pickle_in)
print(LR)
app = Flask(__name__, template_folder = 'Template')

@app.route('/')
def home():
    return render_template('dbp.html')

@app.route('/predict', methods=['POST'])
def predict():
    if request.method == 'POST':
        preg = int(request.form['Pregnancies'])
        glucose = int(request.form['Glucose'])
        bp = int(request.form['BloodPressure'])
        skin = int(request.form['SkinThickness'])
        bmi = float(request.form['BMI'])
        insulin = int(request.form['Insulin'])
        dpf = float(request.form['DiabetesPedigreeFunction'])
        age = int(request.form['Age'])
        data = np.array([[preg, glucose, bp, skin, bmi, insulin, dpf, age]])
        my_prediction = LR.predict(data)
        
        return render_template('result.html', prediction = my_prediction)
if __name__ == "__main__":
    app.run(debug = True)